# NFL Family Picks (Vite + React + Tailwind)
Live scores via ESPN scoreboard, team logos, Rowan photo upload, Vercel/Netlify ready.

## Dev
npm i
npm run dev

## Deploy
- Vercel: import repo, framework = Vite. (vercel.json included)
- Netlify: build `npm run build`, publish `dist/` (netlify.toml included).
