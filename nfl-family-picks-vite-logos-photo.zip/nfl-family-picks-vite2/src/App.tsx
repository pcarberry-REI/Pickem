import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Loader, RefreshCw, Trophy, Upload, Undo2 } from 'lucide-react'
import { TEAMS } from './teams'

type TeamAbbr = string
type Game = {
  id: string
  homeTeam: TeamAbbr
  awayTeam: TeamAbbr
  homeScore: number | null
  awayScore: number | null
  status: 'Scheduled' | 'In Progress' | 'Final'
  isComplete: boolean
  winner: TeamAbbr | null
  date: string
  time: string
}

type Member = { id: number; name: string; avatar: string; color: string }

const FAMILY_BASE: Member[] = [
  { id: 1, name: 'Dad', avatar: '👨', color: 'bg-blue-500' },
  { id: 2, name: 'Mom', avatar: '👩', color: 'bg-pink-500' },
  { id: 3, name: 'Cannon', avatar: '🧒', color: 'bg-green-500' },
  { id: 4, name: 'Hadley', avatar: '👧', color: 'bg-purple-500' },
  { id: 5, name: 'Rowan', avatar: 'photo', color: 'bg-orange-500' },
]

const LS_KEY = 'nfl-family-picks:vite'
type Persisted = {
  currentWeek: number
  picks: Record<string, TeamAbbr>
  gamesByWeek: Record<number, Game[]>
  rowanPhotoDataUrl?: string | null
}

function loadState(): Persisted {
  try {
    const raw = localStorage.getItem(LS_KEY)
    if (!raw) throw new Error('nope')
    const parsed = JSON.parse(raw) as Persisted
    if (!parsed.gamesByWeek || !parsed.picks) throw new Error('bad')
    return parsed
  } catch {
    return { currentWeek: 1, picks: {}, gamesByWeek: { 1: [] }, rowanPhotoDataUrl: null }
  }
}

function saveState(s: Persisted) {
  localStorage.setItem(LS_KEY, JSON.stringify(s))
}

async function fetchWeekGames(week: number): Promise<Game[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?week=${week}&season=2025&seasontype=2`
  try {
    const res = await fetch(url)
    const data = await res.json()
    const events: any[] = data?.events ?? []
    return events.map((e: any, idx: number) => {
      const comp = e.competitions?.[0]
      const d = new Date(e.date)
      const localDate = d.toLocaleDateString(undefined, { month: 'numeric', day: 'numeric' })
      const localTime = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
      const teams = comp?.competitors ?? []
      const home = teams.find((t: any) => t.homeAway === 'home')
      const away = teams.find((t: any) => t.homeAway === 'away')
      const statusDesc = e?.status?.type?.description ?? 'Scheduled'
      const completed = !!e?.status?.type?.completed
      const winner = teams.find((t: any) => t.winner)?.team?.abbreviation ?? null
      return {
        id: String(e.id ?? idx + 1),
        homeTeam: home?.team?.abbreviation ?? 'UNK',
        awayTeam: away?.team?.abbreviation ?? 'UNK',
        homeScore: home?.score ? Number(home.score) : null,
        awayScore: away?.score ? Number(away.score) : null,
        status: completed ? 'Final' : statusDesc,
        isComplete: completed,
        winner: winner || null,
        date: localDate,
        time: localTime,
      } as Game
    })
  } catch (e) {
    console.error('ESPN fetch failed', e)
    return []
  }
}

function PillButton({active, onClick, children}:{active?:boolean; onClick?:()=>void; children:React.ReactNode}){
  return (
    <button onClick={onClick} className={`px-6 py-3 rounded-full font-bold text-lg transition-all ${active ? 'bg-white text-blue-600 shadow-lg scale-105' : 'bg-blue-600 text-white hover:bg-blue-700'}`}>{children}</button>
  )
}

function TeamLogo({abbr, size='w-12 h-12', className=''}:{abbr:string; size?:string; className?:string}){
  const [broken, setBroken] = useState(false)
  const meta = (TEAMS as any)[abbr]
  if (!meta || broken) {
    return <div className={`${size} ${className} bg-gradient-to-br from-gray-600 to-gray-800 text-white rounded-full flex items-center justify-center font-extrabold border-2 border-white shadow`}>{abbr}</div>
  }
  return <img src={meta.logo} alt={`${meta.shortName} logo`} className={`${size} ${className} object-contain rounded-lg bg-white`} onError={() => setBroken(true)} loading="lazy" />
}

function Avatar({member, size='normal', rowanPhoto}:{member:Member; size?:'small'|'normal'|'large'|'xlarge'; rowanPhoto:string|null}){
  const sizes: Record<string,string> = { small:'w-6 h-6', normal:'w-8 h-8', large:'w-12 h-12', xlarge:'w-16 h-16' }
  const textSizes: Record<string,string> = { small:'text-xl', normal:'text-2xl', large:'text-3xl', xlarge:'text-4xl' }
  if (member.name === 'Rowan' && rowanPhoto) {
    return <img src={rowanPhoto} alt="Rowan" className={`${sizes[size]} rounded-full object-cover border-2 border-white shadow-lg`} />
  }
  return <span className={textSizes[size]}>{member.avatar}</span>
}

export default function App(){
  const [tab, setTab] = useState<'picks'|'standings'|'admin'>('picks')
  const [state, setState] = useState<Persisted>(() => loadState())
  const [loading, setLoading] = useState(false)

  const family = useMemo<Member[]>(() => FAMILY_BASE, [])

  const currentGames = state.gamesByWeek[state.currentWeek] || []

  useEffect(() => { saveState(state) }, [state])

  useEffect(() => {
    let stopped = false
    const load = async () => {
      setLoading(true)
      const games = await fetchWeekGames(state.currentWeek)
      if (!stopped) {
        setState(prev => ({...prev, gamesByWeek: {...prev.gamesByWeek, [prev.currentWeek]: games}}))
      }
      setLoading(false)
    }
    load()
    const id = setInterval(load, 60_000)
    return () => { stopped = true; clearInterval(id) }
  }, [state.currentWeek])

  function makePick(gameId:string, team:TeamAbbr, memberId:number){
    setState(prev => ({...prev, picks: {...prev.picks, [`${gameId}-${memberId}`]: team }}))
  }

  const standings = useMemo(() => {
    const all = Object.values(state.gamesByWeek).flat()
    return family.map(m => {
      let wins = 0, total = 0
      for (const g of all){
        if (!g.winner) continue
        const pick = state.picks[`${g.id}-${m.id}`]
        if (pick){ total++; if (pick === g.winner) wins++ }
      }
      return { ...m, wins, total, pct: total>0 ? (wins/total*100).toFixed(1) : '0.0' }
    }).sort((a,b)=>b.wins-a.wins)
  }, [family, state.gamesByWeek, state.picks])

  return (
    <div className="max-w-6xl mx-auto p-4 text-white">
      <div className="text-center mb-8">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow-lg">🏈 Family Football Picks! 🏈</h1>
        <div className="flex justify-center gap-4 mb-6">
          <PillButton active={tab==='picks'} onClick={()=>setTab('picks')}>Make Picks</PillButton>
          <PillButton active={tab==='standings'} onClick={()=>setTab('standings')}>Leaderboard</PillButton>
          <PillButton active={tab==='admin'} onClick={()=>setTab('admin')}>Results</PillButton>
        </div>
      </div>

      <div className="text-center mb-6">
        <div className="inline-flex bg-white rounded-full p-2 shadow-lg items-center text-gray-900">
          <button onClick={()=>setState(s=>({...s, currentWeek: Math.max(1, s.currentWeek-1)}))} className="px-4 py-2 rounded-full bg-gray-200 hover:bg-gray-300 font-bold">← Prev</button>
          <span className="px-6 py-2 font-bold text-xl text-blue-600">Week {state.currentWeek}</span>
          <button onClick={()=>setState(s=>({...s, currentWeek: Math.min(18, s.currentWeek+1)}))} className="px-4 py-2 rounded-full bg-gray-200 hover:bg-gray-300 font-bold">Next →</button>
          <button onClick={()=>setLoading(true)} className="ml-2 px-4 py-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white font-bold flex items-center gap-2">
            {loading ? <Loader className="animate-spin" size={16}/> : <RefreshCw size={16}/>} Refresh
          </button>
        </div>
      </div>

      {loading && <div className="text-center italic mb-4">Loading live scores…</div>}

      {tab==='picks' && (
        <div className="grid gap-6">
          <h2 className="text-2xl font-bold text-center mb-2">Who do you think will win? 🤔</h2>
          {currentGames.length===0 && <div className="text-center text-white/90">No games found for this week (yet).</div>}
          {currentGames.map(game => (
            <div key={game.id} className="bg-white rounded-xl p-6 shadow-lg text-gray-800">
              <div className="text-center mb-4">
                <div className="text-lg font-bold text-gray-700">{game.date} at {game.time}</div>
                <div className="text-sm text-gray-500">{game.status}</div>
                {game.isComplete && game.winner && (
                  <div className="text-green-700 font-bold text-xl mt-2">Winner: {game.winner}</div>
                )}
              </div>

              <div className="flex items-center justify-between mb-6">
                <div className="text-center flex-1">
                  <div className="flex justify-center mb-2"><TeamLogo abbr={game.awayTeam}/></div>
                  <div className="font-bold text-xl">{(TEAMS as any)[game.awayTeam]?.shortName || game.awayTeam}</div>
                  {game.isComplete && <div className="text-2xl font-extrabold">{game.awayScore ?? '-'}</div>}
                </div>
                <div className="text-3xl font-bold text-gray-500 mx-6">@</div>
                <div className="text-center flex-1">
                  <div className="flex justify-center mb-2"><TeamLogo abbr={game.homeTeam}/></div>
                  <div className="font-bold text-xl">{(TEAMS as any)[game.homeTeam]?.shortName || game.homeTeam}</div>
                  {game.isComplete && <div className="text-2xl font-extrabold">{game.homeScore ?? '-'}</div>}
                </div>
              </div>

              <div className="grid gap-3">
                {FAMILY_BASE.map(member => (
                  <div key={member.id} className="flex items-center gap-4">
                    <div className="flex items-center gap-2 w-32">
                      <Avatar member={member} rowanPhoto={state.rowanPhotoDataUrl || null} />
                      <span className="font-bold text-gray-700">{member.name}</span>
                    </div>
                    <div className="flex gap-2 flex-1">
                      <button onClick={()=>setState(prev=>({...prev, picks:{...prev.picks, [`${game.id}-${member.id}`]: game.awayTeam}}))} className={`${state.picks[`${game.id}-${member.id}`]===game.awayTeam ? `${member.color} text-white scale-105 shadow-lg` : 'bg-gray-200 hover:bg-gray-300 text-gray-700'} flex-1 py-3 rounded-lg font-bold transition-all`}>
                        <TeamLogo abbr={game.awayTeam} size="w-6 h-6" className="inline-block mr-2 align-middle"/>{(TEAMS as any)[game.awayTeam]?.shortName || game.awayTeam}
                      </button>
                      <button onClick={()=>setState(prev=>({...prev, picks:{...prev.picks, [`${game.id}-${member.id}`]: game.homeTeam}}))} className={`${state.picks[`${game.id}-${member.id}`]===game.homeTeam ? `${member.color} text-white scale-105 shadow-lg` : 'bg-gray-200 hover:bg-gray-300 text-gray-700'} flex-1 py-3 rounded-lg font-bold transition-all`}>
                        <TeamLogo abbr={game.homeTeam} size="w-6 h-6" className="inline-block mr-2 align-middle"/>{(TEAMS as any)[game.homeTeam]?.shortName || game.homeTeam}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==='standings' && (
        <div className="bg-white rounded-xl p-6 shadow-lg text-gray-800">
          <h2 className="text-3xl font-bold text-center mb-6">🏆 Family Leaderboard 🏆</h2>
          {/* A simple placeholder; can compute live like earlier version */}
          <p className="text-center text-gray-600">Make some picks and set winners to see standings.</p>
        </div>
      )}

      {tab==='admin' && (
        <div className="bg-white rounded-xl p-6 shadow-lg text-gray-800">
          <h2 className="text-2xl font-bold text-center mb-4">📸 Rowan Photo (optional)</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            <label className="px-4 py-2 rounded bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer flex items-center gap-2">
              <Upload size={16}/> Upload Rowan Photo
              <input type="file" accept="image/*" className="hidden" onChange={(e)=>{
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = ()=> setState(prev=>({...prev, rowanPhotoDataUrl: String(reader.result)}))
                reader.readAsDataURL(file)
                e.currentTarget.value = ''
              }}/>
            </label>
            {state.rowanPhotoDataUrl && (
              <button className="px-4 py-2 rounded bg-gray-600 hover:bg-gray-700 text-white font-bold flex items-center gap-2" onClick={()=>setState(prev=>({...prev, rowanPhotoDataUrl: null}))}><Undo2 size={16}/> Remove Photo</button>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
